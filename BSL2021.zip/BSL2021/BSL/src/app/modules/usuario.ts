export interface usuario {
    IdUsuario:number;
    Nombre:string;
    ValorDocumentoIdentidad:string; 
    Contrasena:string;
    Administrador:boolean;
}