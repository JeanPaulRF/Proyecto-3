export interface movimientos {
    Fecha:string;
    Compra:string;
    Venta:string;
    IdMonedaMovimiento:string;
    MontoMovimiento:string;
    IdMonedaCuenta:string;
    MontoCuenta:string;
    Descripcion:string;
    NuevoSaldo:String;
}