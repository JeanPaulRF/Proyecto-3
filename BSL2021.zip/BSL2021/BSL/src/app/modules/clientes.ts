export interface clientes {
    IdPersona: number;
    Nombre: string;
    ValorDocumentoIdentidad: number;
    TipoIdentidad: number;
    FechaDeNacimiento: string;
    Email: string;
    Telefono1: number;
    Telefono2: number;
}