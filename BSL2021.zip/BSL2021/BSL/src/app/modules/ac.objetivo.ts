export interface beneficiarios {

    
}