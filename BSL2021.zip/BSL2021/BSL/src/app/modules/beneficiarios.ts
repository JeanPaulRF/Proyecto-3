
export interface beneficiarios {
    Identificacion:string;
    NumeroCuenta:string;
    Parentesco:number;
    Porcentaje:number;
    Nombre:string;
    FechaDeNacimiento:string;
    Email:string;
    Telefono1:number;
    Telefono2:number;
}