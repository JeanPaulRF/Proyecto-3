
export interface estados {
    id:string;
    FechaInicio:string;
    FechaFin:string;
    SaldoInicial:number;
    SaldoFinal:number;
    IdCuentaAhorro:string;
    QOperacionesHumano:number;
    QOperacionesATM:number;
    Activo:number;
    SaldoMinimoMes:number;
}