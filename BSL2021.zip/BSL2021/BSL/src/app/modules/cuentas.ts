export interface cuentas {
 //   IdCuentaAhorro: number;
   // IdentificacionCliente: number;
   Identificacion:string;
   NumeroCuenta: string;
  //  Saldo: number;
    FechaConstitucion: string;
    //ValorDocumentoIdentidadCliente: string;
    TipoCuentaAhorro: number;
}