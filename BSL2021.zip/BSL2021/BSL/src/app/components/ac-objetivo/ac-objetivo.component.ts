import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ac-objetivo',
  templateUrl: './ac-objetivo.component.html',
  styleUrls: ['./ac-objetivo.component.scss']
})
export class AcObjetivoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
