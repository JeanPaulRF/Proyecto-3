export interface users {
    IdUsuario:number;
    Nombre:string;
    ValorDocumentoIdentidad:string;
    Contrasena:string;
    Administrador:boolean;
}