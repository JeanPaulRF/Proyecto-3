
export const config = {
  user: 'sa',
  password: '12345',
  server: 'localhost',
  port: 1433,
  database: 'Banco'
};
